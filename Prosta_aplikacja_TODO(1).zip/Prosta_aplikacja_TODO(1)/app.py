from flask import Flask, request, render_template, redirect, url_for

from forms import LibraryForm
from models import library

app = Flask(__name__)
app.config["SECRET_KEY"] = "nininini"

@app.route("/biblioteka/", methods=["GET", "POST"])
def todos_list():
    form = LibraryForm()
    error = ""
    if request.method == "POST":
        if form.validate_on_submit():
            library.create(form.data)
            library.save_all()
        return redirect(url_for("todos_list"))

    return render_template("biblioteka.html", form=form, library=library.all(), error=error)


@app.route("/biblioteka/<int:library_id>/", methods=["GET", "POST"])
def todo_details(library_id):
    todo = library.get(library_id - 1)
    form = LibraryForm(data=todo)

    if request.method == "POST":
        if form.validate_on_submit():
            library.update(library_id - 1, form.data)
        return redirect(url_for("todos_list"))
    return render_template("książka.html", form=form, library_id=library_id)


if __name__ == "__main__":
    app.run(debug=True)