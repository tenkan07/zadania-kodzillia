Aplikacja "Biblioteka" jest prostym systemem do zarządzania książkami. Pozwala użytkownikowi dodawać nowe książki, edytować istniejące, oznaczać je jako przeczytane lub nieprzeczytane oraz wyświetlać listę wszystkich książek w bibliotece.
Instalacja
Aby zainstalować aplikację, wykonaj poniższe kroki:

Pobierz kod aplikacji z repozytorium lub skopiuj podany kod.

Upewnij się, że masz zainstalowanego Pythona na swoim systemie.

Zainstaluj wymagane moduły, wpisując następującą komendę w wierszu poleceń/terminalu:
pip install -r requirements.txt
Utwórz plik library.json (jeśli nie istnieje) i dodaj w nim początkowe dane książek w formacie JSON, na przykład:
[
    {
        "title": "Pan Tadeusz",
        "description": "-",
        "autor": "Adam Mickiewicz",
        "done": true
    },
]
Uruchom flaska, wpisując następującą komendę w wierszu poleceń/terminalu:
set FLASK_APP=app.py
flask run
Aplikacja powinna być teraz dostępna pod adresem http://localhost:5000/biblioteka/ w przeglądarce internetowej.
Użycie
Po uruchomieniu aplikacji, będziesz mógł korzystać z następujących funkcji:

Wyświetlanie listy książek: Na stronie głównej http://localhost:5000/biblioteka/ zostanie wyświetlona tabela z listą książek w bibliotece. Będą widoczne kolumny z tytułem, opisem, autorem i informacją, czy książka jest oznaczona jako przeczytana.
Dodawanie nowej książki: Na stronie głównej znajduje się formularz, w którym można wprowadzić dane nowej książki (tytuł, opis, autor). Po wypełnieniu formularza i kliknięciu przycisku "Prześlij"