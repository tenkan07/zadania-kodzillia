from unittest.mock import Mock
import tmdb_client
from main import app


def test_get_single_movie(monkeypatch):
    
    movie_id = 123
    mock_response = {
        'id': movie_id,
        'title': 'Test Movie',
        'director': 'Test Director',
        'year': 2023,
    }
    
   
    mock_get = Mock()
    mock_get.return_value.json.return_value = mock_response
    
   
    monkeypatch.setattr('tmdb_client.requests.get', mock_get)
    
    
    movie = tmdb_client.get_single_movie(movie_id)
    
    
    assert movie['id'] == movie_id
    assert movie['title'] == mock_response['title']
    assert movie['director'] == mock_response['director']
    assert movie['year'] == mock_response['year']
   
def test_get_movie_images(monkeypatch):
    
    movie_id = 123
    mock_response = {
        'backdrops': [
            {'file_path': '/backdrop1.jpg'},
            {'file_path': '/backdrop2.jpg'}
        ],
        'posters': [
            {'file_path': '/poster1.jpg'},
            {'file_path': '/poster2.jpg'}
        ]
    }
    
    
    mock_get = Mock()
    mock_get.return_value.json.return_value = mock_response
    
    
    monkeypatch.setattr('tmdb_client.requests.get', mock_get)
    
    
    images = tmdb_client.get_movie_images(movie_id)
    
    
    assert len(images['backdrops']) == 2
    assert len(images['posters']) == 2  
    
def test_get_single_movie_cast(monkeypatch):
    
    movie_id = 123
    mock_response = {
        'cast': [
            {'name': 'Actor 1', 'character': 'Character 1'},
            {'name': 'Actor 2', 'character': 'Character 2'}
        ]
    }
    
    
    mock_get = Mock()
    mock_get.return_value.json.return_value = mock_response
    
    
    monkeypatch.setattr('tmdb_client.requests.get', mock_get)
    
    
    cast = tmdb_client.get_single_movie_cast(movie_id)
    
    
    assert len(cast) == 2
    assert cast[0]['name'] == 'Actor 1'
    assert cast[0]['character'] == 'Character 1'
    assert cast[1]['name'] == 'Actor 2'
    assert cast[1]['character'] == 'Character 2'


def test_homepage(monkeypatch):
   api_mock = Mock(return_value={'results': []})
   monkeypatch.setattr("tmdb_client.call_tmdb_api", api_mock)

   with app.test_client() as client:
       response = client.get('/')
       assert response.status_code == 200
       api_mock.assert_called_once_with('movie/popular')

