from flask import Flask, render_template
from django.shortcuts import render
import requests
import tmdb_client

app = Flask(__name__)

def get_popular_movies():
    endpoint = "https://api.themoviedb.org/3/movie/popular"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    return response.json()
#print(get_popular_movies())

def get_poster_url(poster_api_path, size="w342"):
    base_url = "https://image.tmdb.org/t/p/"
    return f"{base_url}{size}/{poster_api_path}"

@app.context_processor
def utility_processor():
    def tmdb_image_url(path, size):
        return tmdb_client.get_poster_url(path, size)
    return {"tmdb_image_url": tmdb_image_url}

def get_movies(how_many, list_type="popular"):
    endpoint = f"https://api.themoviedb.org/3/movie/{list_type}"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    response.raise_for_status()
    data = response.json()
    return data["results"][:how_many]

def get_single_movie(movie_id):
    endpoint = f"https://api.themoviedb.org/3/movie/{movie_id}"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    return response.json()

def get_single_movie_cast(movie_id):
    endpoint = f"https://api.themoviedb.org/3/movie/{movie_id}/credits"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    return response.json()["cast"]

def get_movies_list(list_type):
    endpoint = f"https://api.themoviedb.org/3/movie/{list_type}"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    response.raise_for_status()
    return response.json()

def get_movies_list(list_type):
    endpoint = f"https://api.themoviedb.org/3/movie/{list_type}"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    response.raise_for_status()
    return response.json()

def home(request):
    list_type = request.GET.get("list_type", "popular")

    # Sprawdzenie poprawności wybranego typu listy
    valid_list_types = ["popular", "top_rated", "upcoming"]
    if list_type not in valid_list_types:
        list_type = "popular"

    movies = get_movies(list_type, 10)

    context = {
        "movies": movies,
        "list_type": list_type,
        "valid_list_types": valid_list_types
    }

    return render(request, "home.html", context)

def get_movie_images(movie_id):
    endpoint = f"https://api.themoviedb.org/3/movie/{movie_id}/images"
    api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
    headers = {
        "Authorization": f"Bearer {api_token}"
    }
    response = requests.get(endpoint, headers=headers)
    return response.json()

def call_tmdb_api(endpoint):
   full_url = f"https://api.themoviedb.org/3/{endpoint}"
   api_token = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZDE2ZDE5YzVhZjcyODllODYxYWE0YTBjYjI0ODIzMCIsInN1YiI6IjY0NjNjODA2OGM0NGI5NzgwOGZmZjU1YiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.wkBZjatjR0xV5WCnVrBB3mwgzaPuyZ_F26m7rEOdnt8"
   headers = {
       "Authorization": f"Bearer {api_token}"
   }
   response = requests.get(full_url, headers=headers)
   response.raise_for_status()
   return response.json()    

def get_movies_list(list_type):
   return call_tmdb_api(f"movie/{list_type}")